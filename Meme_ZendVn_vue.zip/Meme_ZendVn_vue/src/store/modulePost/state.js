export default {
    listPosts: [],
    postDetail: null,
    categories: [
        { 
            text: 'Ảnh troll',
            id: 1
        }, { 
            text: 'Cách gặp ma',
            id: 2
        }, { 
            text: 'Clip funvl',
            id: 3
        }, { 
            text: 'Xác ướp',
            id: 4
        }, { 
            text: 'Ảo tưởng sức mạnh',
            id: 5
        }, { 
            text: 'Running man',
            id: 6
        }, { 
            text: 'Ảnh bựa VL',
            id: 7
        }, { 
            text: 'Faptv',
            id: 8
        }, { 
            text: '500 anh em',
            id: 9
        }, { 
            text: 'Ancient aliens',
            id: 10
        }, { 
            text: 'Video cảm động',
            id: 11
        }, { 
            text: 'Siêu nhân',
            id: 12
        }, { 
            text: 'Video kinh dị',
            id: 13
        }, { 
            text: 'Thánh cuồng',
            id: 14
        }, { 
            text: 'Comment hài',
            id: 15
        }, { 
            text: 'Nhạc Remix hay',
            id: 16
        }, { 
            text: 'Ảnh ấn tượng',
            id: 17
        }, { 
            text: 'Pháo hoa Tết',
            id: 18
        }, { 
            text: 'Ji Suk Jin',
            id: 19
        }, { 
            text: 'Cao Bá Hưng',
            id: 20
        }, { 
            text: 'Hài Quang Thắng',
            id: 21
        }, { 
            text: 'Xăm trổ',
            id: 22
        }, { 
            text: 'Chuyện tình lãng mạn',
            id: 23
        }, { 
            text: 'Giang hồ',
            id: 24
        }
    ]

}