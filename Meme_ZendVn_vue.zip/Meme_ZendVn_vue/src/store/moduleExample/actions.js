export default {
    increment ({ commit }) {
        commit('increment')
    }
}