export default {
    test: state => {
        return state
    }
}