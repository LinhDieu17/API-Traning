<template>
    <footer>
        <div class="ass1-footer">
            <div class="container">
                <p class="text-center">Cộng đồng chế ảnh ZendVN</p>
            </div>
        </div>
    </footer>
</template>

<script>
export default {
    name: 'app-footer'
}
</script>

<style>

</style>